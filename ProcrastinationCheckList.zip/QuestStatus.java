

public enum QuestStatus {
	COMPLETED,FAILED,INCOMPLETE;
}
